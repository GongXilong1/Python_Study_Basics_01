def receive():
    return "这是来自 100xx 的短信"

